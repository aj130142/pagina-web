document.getElementById('scroll').addEventListener('click', function() {
    document.getElementById('informaciongeneral').scrollIntoView({ behavior: 'smooth' });
});